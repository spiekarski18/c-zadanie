﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class CreditOwner
{
    private int numerKonta;
    private bool stanKonta;
    private string wlascicielKonta;
    private object daneKontaktowe;
    private long iloscKredytu;

    public CreditOwner(int numerKonta, double stanKonta, string wlascicielKonta, int daneKontaktowe, long iloscKredytu)
    {
        this.numerKonta = numerKonta;
        this.stanKonta = stanKonta;
        this.wlascicielKonta = wlascicielKonta;
        this.daneKontaktowe = daneKontaktowe;
        this.iloscKredytu = iloscKredytu;
    }

    public int GetNumerKonta()
    {
        return this.numerKonta;
    }

    public void SetNumerKonta(int numerKonta)
    {
        this.numerKonta = numerKonta;
    }

    public bool GetStanKonta()
    {
        return this.stanKonta;
    }

    public void SetStanKonta(double stanKonta)
    {
        this.stanKonta = stanKonta;
    }

    public string GetWlascicielKonta()
    {
        return this.wlascicielKonta;
    }

    public void SetWlascicielKonta(string wlascicielKonta)
    {
        this.wlascicielKonta = wlascicielKonta;
    }

    public object GetDaneKontaktowe()
    {
        return this.daneKontaktowe;
    }

    public void SetDaneKontaktowe(int daneKontaktowe)
    {
        this.daneKontaktowe = daneKontaktowe;
    }

    public long GetIloscKredytu()
    {
        return this.iloscKredytu;
    }

    public void SetIloscKredytu(long iloscKredytu)
    {
        this.iloscKredytu = iloscKredytu;
    }
}
