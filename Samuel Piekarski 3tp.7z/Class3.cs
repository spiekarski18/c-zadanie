﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Bank
{
    private string nazwaBanku;
    private int iloscPracownikow;
    private double iloscSrodkow;
    private long iloscKredytobiorcow; 
    private object iloscLokacji; 

    public Bank(string nazwaBanku, int iloscPracownikow, double iloscSrodkow, long iloscKredytobiorcow, object iloscLokacji)
    {
        this.nazwaBanku = nazwaBanku;
        this.iloscPracownikow = iloscPracownikow;
        this.iloscSrodkow = iloscSrodkow;
        this.iloscKredytobiorcow = iloscKredytobiorcow;
        this.iloscLokacji = iloscLokacji;
    }

    public string GetNazwaBanku()
    {
        return this.nazwaBanku;
    }

    public void SetNazwaBanku(string nazwaBanku)
    {
        this.nazwaBanku = nazwaBanku;
    }

    public int GetIloscPracownikow()
    {
        return this.iloscPracownikow;
    }

    public void SetIloscPracownikow(int iloscPracownikow)
    {
        this.iloscPracownikow = iloscPracownikow;
    }

    public int GetIloscSrodkow()
    {
        return this.iloscSrodkow;
    }

    public void SetIloscSrodkow(double iloscSrodkow)
    {
        this.iloscSrodkow = iloscSrodkow;
    }

    public long GetIloscKredytobiorcow()
    {
        return this.iloscKredytobiorcow;
    }

    public void SetIloscKredytobiorcow(long iloscKredytobiorcow)
    {
        this.iloscKredytobiorcow = iloscKredytobiorcow;
    }

    public object GetIloscLokacji()
    {
        return this.iloscLokacji;
    }

    public void SetIloscLokacji(object iloscLokacji)
    {
        this.iloscLokacji = iloscLokacji;
    }
}

