﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie_c_
{
    public class Person
    {
        private string Name;
        private string Surname;
        private int Wiek;
        private bool Plec;
        private double Pesel;

        public Person(string name, string surname, int wiek, bool plec, double pesel)
        {
            Name = name;
            Surname = surname;
            Wiek = wiek;
            Plec = plec;
            Pesel = pesel;
        }

         public string getName() 
        {
            return this.Name;

        }
        public void setName(string name)
        {
            this.Name = name;
        }
        public string getSurname()
        {
            return this.Surname;
        }

        public void setSurname(string surname)
        {
            this.Surname = surname;
        }

        public int getWiek()
        {
            return this.Wiek;
        }

        public void setWiek(int wiek)
        {
            this.Wiek = wiek;
        }

        public bool getPlec()
        {
            return this.Plec;
        }

        public void setPlec(bool plec)
        {
            this.Plec = plec;
        }

        public double getPesel()
        {
            return this.Pesel;
        }

        public void setPesel(double pesel)
        {
            this.Pesel = pesel;
        }


    }
}
